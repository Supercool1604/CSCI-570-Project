g++ 3164894955_9165933890_7293382981_efficient.cpp -o efficient
./efficient input.txt