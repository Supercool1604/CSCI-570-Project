g++ 3164894955_9165933890_7293382981_basic.cpp -o basic
./basic input.txt